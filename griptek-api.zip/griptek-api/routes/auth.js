// 로그인 — admin_users(email, pass_hash bcrypt, role) 조회 → JWT 발급
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../db');
const ah = require('../asyncH');
const router = express.Router();

router.post('/login', ah(async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'email/password required' });

  const [rows] = await pool.query(
    'SELECT id, email, pass_hash, role FROM admin_users WHERE email = ? LIMIT 1',
    [String(email).trim().toLowerCase()],
  );
  const u = rows[0];
  if (!u || !(await bcrypt.compare(password, u.pass_hash))) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = jwt.sign(
    { sub: u.id, email: u.email, role: u.role },
    process.env.JWT_SECRET,
    { expiresIn: '8h' },
  );
  res.json({ token, role: u.role });
}));

module.exports = router;
